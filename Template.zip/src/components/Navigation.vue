<script setup lang="ts"></script>

<template>
  <nav>
    <ul>
      <li><router-link class="" to="/">Главная</router-link></li>
      <li><router-link class="" to="/About">О нас</router-link></li>
    </ul>
  </nav>
</template>

<style scoped></style>
