<script setup lang="ts"></script>

<template>
  <footer>
    <hr />
    <h1>Футер</h1>
  </footer>
</template>

<style scoped></style>
