<script setup lang="ts">
  import Navigation from '../components/Navigation.vue'
</script>

<template>
  <header><Navigation /></header>
</template>

<style scoped></style>
