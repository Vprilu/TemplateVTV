export const routes = [
  { path: '/', component: () => import('./pages/Home.vue') },
  { path: '/About', component: () => import('./pages/About.vue') },
]
